#!/bin/sh
while true; do
    date_formatted=$(date '+%a %d %b %Y %H:%M')
    battery=$(cat /sys/class/power_supply/BAT0/capacity 2>/dev/null)% 
    echo "%{l}   Void Linux %{c} $date_formatted %{r} 🔋 $battery" 
    sleep 1
done | lemonbar -p -B "#1e1e2e" -F "#f8f8f2" -g x24 -f "monospace-9" -f "FontAwesome-10"
