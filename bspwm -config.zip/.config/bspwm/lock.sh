#!/bin/sh
i3lock -c 000000
