#!/bin/sh
feh --bg-scale ~/.config/bspwm/config/wallpaper.jpg
picom --config ~/.config/bspwm/config/picom.conf &
dunst -config ~/.config/bspwm/config/dunstrc &
~/.config/bspwm/lemonbar.sh &
xclip -selection clipboard &
