#!/bin/sh
xclip -selection clipboard -o
