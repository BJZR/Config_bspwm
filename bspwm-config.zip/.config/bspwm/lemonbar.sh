#!/bin/sh
source ~/.config/bspwm/config/colors.sh
while :; do
    TIME=$(date '+%H:%M')
    VOL=$(amixer get Master | grep -o '[0-9]*%' | head -1)
    BRIGHT=$(xbacklight -get | cut -d'.' -f1)
    echo "%{l}  Kitty %{c} $VOL | ☀ $BRIGHT %{r}$TIME" 
    sleep 1
done | lemonbar -g x24 -B "$color_bg" -F "$color_fg" -f 'monospace-10'
