#!/bin/sh
while :; do
    TIME=$(date '+%H:%M:%S')
    VOL=$(amixer get Master | grep -o '[0-9]*%' | head -1)
    BRIGHT=$(xbacklight -get | cut -d'.' -f1)
    echo "%{l}  Kitty %{c} $VOL | ☀ $BRIGHT %{r}$TIME"
    sleep 1
done | lemonbar -g x20 -B '#282a36' -F '#f8f8f2' -f 'monospace-10'
