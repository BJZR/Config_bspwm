#!/bin/sh
i3lock -c 1e1e2e
