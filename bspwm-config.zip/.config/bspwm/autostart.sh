#!/bin/sh
feh --bg-scale ~/.config/bspwm/themes/morado-oscuro/wallpaper.jpg
picom --config ~/.config/bspwm/picom.conf &
dunst -conf ~/.config/bspwm/dunstrc &
~/.config/bspwm/polybar/launch.sh &
