#!/bin/sh
THEME_DIR="$HOME/.config/bspwm/themes/$1"
if [ -d "$THEME_DIR" ]; then
    cp $THEME_DIR/colors.ini ~/.config/bspwm/polybar/colors.ini
    cp $THEME_DIR/rofi.rasi ~/.config/bspwm/themes/morado-oscuro/rofi.rasi
    feh --bg-scale $THEME_DIR/wallpaper.jpg
    pkill -USR1 -x polybar
else
    echo "Tema no encontrado"
fi
