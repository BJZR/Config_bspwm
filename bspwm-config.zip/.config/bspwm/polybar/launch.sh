#!/bin/bash
pkill polybar
polybar topbar -c ~/.config/bspwm/polybar/config.ini &
