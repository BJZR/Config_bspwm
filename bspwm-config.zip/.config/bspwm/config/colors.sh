#!/bin/sh
color_bg="#1e1e2e"
color_fg="#f8f8f2"
color_accent="#bd93f9"
