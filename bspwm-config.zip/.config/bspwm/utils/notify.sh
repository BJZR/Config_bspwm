#!/bin/sh
notify-send "Notificación BSPWM" "$1"
