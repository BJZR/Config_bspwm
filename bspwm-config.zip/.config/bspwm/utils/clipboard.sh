#!/bin/sh
xclip -o -selection clipboard
