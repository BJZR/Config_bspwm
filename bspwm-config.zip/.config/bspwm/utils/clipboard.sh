#!/bin/sh
xclip -o -selection clipboard | rofi -dmenu -p "Clipboard"
