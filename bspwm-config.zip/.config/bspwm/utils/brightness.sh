#!/bin/sh
if [ "$1" = "up" ]; then
    xbacklight -inc 10
else
    xbacklight -dec 10
fi
