#!/bin/sh
case "$1" in
  logout) bspc quit ;;
  restart) pkill -USR1 -x bspwm ;;
esac
